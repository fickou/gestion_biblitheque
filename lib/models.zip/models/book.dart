// lib/models/book.dart
class Book {
  final String id;
  final String title;
  final String author;
  final String year;
  final String category;
  final bool available;
  final int copies;
  final String description;

  Book({
    required this.id,
    required this.title,
    required this.author,
    required this.year,
    required this.category,
    required this.available,
    required this.copies,
    required this.description,
  });
}

// Données des livres (à déplacer dans un service séparé si nécessaire)
final Map<String, Book> bookData = {
  "1": Book(
    id: "1",
    title: "Introduction à Python",
    author: "J. Dupont",
    year: "2023",
    category: "Informatique",
    available: true,
    copies: 2,
    description: "Un guide complet pour apprendre les bases de la programmation Python. Idéal pour les débutants souhaitant maîtriser ce langage polyvalent et puissant.",
  ),
};